# stately

== Changelog ==

== 1.0.10 ==
* New: Font Awesome 5 transition completed

== 1.0.9 ==
* Fix: Resolves issue with sample listing data import file

== 1.0.8 ==
* New: Theme identifying class added to body

== 1.0.7 ==
* Fix: IMPress Carousel resizing issue on homepage

== 1.0.6 ==
* New: Font Awesome 5

== 1.0.5 ==
* Fix: Mobile nav menu behavior for Android devices

== 1.0.4 ==
* Fix: Headings displaying white in the editor when using light color scheme
* Fix: Custom colors not carrying over to IDX search page menus
* Fix: Background image not proportionate when using TK Designer

== 1.0.3 ==
* Fix: Issue with sticky header remaining enabled

== 1.0.2 ==
* New: Added customization options to increase/reduce title font size and nav menu font size and padding
* Fix: Off canvas Omnibar search dropdown color
* Fix: Visible horizontal scroll bar and off canvas issue with LayerSlider

== 1.0.1 ==
* Fix: Various display and color issues when using customizer
* Fix: Disable sticky header if mobile is detected due to usability issues

== 1.0 ==
* Initial release
