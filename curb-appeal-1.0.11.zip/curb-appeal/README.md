# curb-appeal

== Changelog ==

= 1.0.11 =
* New: Completed Font Awesome 5 transition

= 1.0.10 =
* Fix: Resolves issue with sample listing data import file

= 1.0.9 =
* New: Added theme identifying class to body

= 1.0.8 =
* New: Minor CSS change

= 1.0.7 =
* New: Font Awesome 5
* Fix: Mobile nav menu behavior for entries with a sub-menu

= 1.0.6 =
* Fix: Tidy up CSS for IDX mobile first templates

= 1.0.5 =
* Fix: Single listing templates updated with Google Maps key if applicable
* Fix: XML files pointing to wrong URLs for media

== 1.0.4 ==
* New: Included single listing templates
* New: Added CSS for mobile first IDX pages
* Fix: Updated documentation link
* Fix: Google font reference

== 1.0.3 ==
* Fix: Additional CSS fix for IDX mobile first map search buttons

== 1.0.2 ==
* Fix: CSS fix for IDX mobile first map search buttons

== 1.0.1 ==
* Fix: CSS fix for font family on some headings

== 1.0 ==
* Initial release
