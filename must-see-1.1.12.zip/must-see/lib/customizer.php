<?php
/* Adds Customizer options for Must See
 */

class MUST_SEE_Customizer extends EQUITY_Customizer_Base {

	/**
	 * Register theme specific customization options
	 */
	public function register( $wp_customize ) {

		$this->home( $wp_customize );
		$this->post( $wp_customize );
		$this->colors( $wp_customize );
		
	}

	private function home( $wp_customize ) {

		global $wp_version;

		//** Add Panel - requires at least 4.0
		if ( version_compare( $wp_version, '4.0', '>=' ) ) {
			$wp_customize->add_panel(
				'home',
				array(
					'title'       => __( 'Home Page', 'must-see'),
					'description' => __( 'Home Page sections', 'must-see'),
					'priority'    => 10,
				)
			);
		}

		//** Add Section
		$wp_customize->add_section(
			'home_top',
			array(
				'title'    => __( 'Home Top', 'must-see'),
				'priority' => 150,
				'panel'    => 'home'
			)
		);

		$wp_customize->add_section(
			'home_middle',
			array(
				'title'    => __( 'Home Middle', 'must-see'),
				'priority' => 151,
				'panel'    => 'home'
			)
		);

		$wp_customize->add_section(
			'home_bottom',
			array(
				'title'    => __( 'Home Bottom', 'must-see'),
				'priority' => 152,
				'panel'    => 'home'
			)
		);

		//* Setting key and default value array
		$settings = array(
			'home_top_title'         => '',
			'home_top_background'    => get_stylesheet_directory_uri() . '/images/bkg-home-top.jpg',
			'home_middle_title'      => '',
			'home_bottom_title'      => '',
			'home_bottom_background' => get_stylesheet_directory_uri() . '/images/bkg-home-bottom.jpg',
		);

		foreach ( $settings as $setting => $default ) {

			$wp_customize->add_setting(
				$setting,
				array(
					'default' => $default,
					'type'    => 'theme_mod'
				)
			);

		}

		//* Home Top Title
		$wp_customize->add_control(
			'home_top_title',
			array(
				'label'      => __( 'Home Top Title', 'must-see' ),
				'section'    => 'home_top',
				'settings'   => 'home_top_title',
				'priority'   => 100,
				'type'       => 'text',
			)
		);

		//* Home Top Background Image
		$wp_customize->add_control(
			new WP_Customize_Image_Control(
				$wp_customize,
				'home_top_background',
				array(
					'label'       => __( 'Home Top Background', 'must-see' ),
					'description' => __( 'Upload an image in <strong>.JPG</strong> format.<br /> Recommended size: <strong>1400 x 600</strong> pixels or similar.', 'must-see' ),
					'section'     => 'home_top',
					'settings'    => 'home_top_background',
					'extensions'  => array( 'jpg' ),
					'priority'    => 100
				)
			)
		);

		//* Home Middle Title
		$wp_customize->add_control(
			'home_middle_title',
			array(
				'label'      => __( 'Home Middle Title', 'must-see' ),
				'section'    => 'home_middle',
				'settings'   => 'home_middle_title',
				'priority'   => 100,
				'type'       => 'text',
			)
		);

		//* Home Bottom Title
		$wp_customize->add_control(
			'home_bottom_title',
			array(
				'label'      => __( 'Home Bottom Title', 'must-see' ),
				'section'    => 'home_bottom',
				'settings'   => 'home_bottom_title',
				'priority'   => 100,
				'type'       => 'text',
			)
		);

		//* Home Bottom Background Image
		$wp_customize->add_control(
			new WP_Customize_Image_Control(
				$wp_customize,
				'home_bottom_background',
				array(
					'label'       => __( 'Home Bottom Background', 'must-see' ),
					'description' => __( 'Upload an image in <strong>.JPG</strong> format.<br /> Recommended size: <strong>1400 x 600</strong> pixels or similar.', 'must-see' ),
					'section'     => 'home_bottom',
					'settings'    => 'home_bottom_background',
					'extensions'  => array( 'jpg' ),
					'priority'    => 100
				)
			)
		);
	}

	private function post( $wp_customize ) {

		global $wp_version;

		//** Add Panel - requires at least 4.0
		if ( version_compare( $wp_version, '4.0', '>=' ) ) {
			$wp_customize->add_panel(
				'single_post',
				array(
					'title'       => __( 'Posts &amp; Pages', 'must-see'),
					'description' => __( 'Single Posts and Pages', 'must-see'),
					'priority'    => 11,
				)
			);
		}

		//** Add Section
		$wp_customize->add_section(
			'single_posts',
			array(
				'title'    => __( 'Single Posts and Pages', 'must-see'),
				'priority' => 201,
				'panel'    => 'single_post'
			)
		);

		//* Setting key and default value array
		$settings = array(
			'singular_header_background' => get_stylesheet_directory_uri() . '/images/bkg-singular-header.jpg',
		);

		foreach ( $settings as $setting => $default ) {

			$wp_customize->add_setting(
				$setting,
				array(
					'default' => $default,
					'type'    => 'theme_mod'
				)
			);
		}

		//* Singular Background Image
		$wp_customize->add_control(
			new WP_Customize_Image_Control(
				$wp_customize,
				'singular_header_background',
				array(
					'label'       => __( 'Single Post/Page Header Background', 'must-see' ),
					'description' => __( 'Upload an image in <strong>.JPG</strong> format to use as the default background for post and page titles.<br /> Recommended size: <strong>1280 x 350</strong> pixels or similar.', 'must-see' ),
					'section'     => 'single_posts',
					'settings'    => 'singular_header_background',
					'extensions'  => array( 'jpg' ),
					'priority'    => 100
				)
			)
		);

	}
	
	//* Colors
	private function colors( $wp_customize ) {
		$wp_customize->add_section(
			'colors',
			array(
				'title'    => __( 'Custom Colors', 'must-see'),
				'priority' => 200,
			)
		);

		//* Setting key and default value array
		$settings = array(
			'primary_color'       => '',
			'primary_color_hover' => '',
			'primary_color_light' => '',
		);

		foreach ( $settings as $setting => $default ) {

			$wp_customize->add_setting(
				$setting,
				array(
					'default' => $default,
					'type'    => 'theme_mod'
				)
			);

		}

		//* Primary Color
		$wp_customize->add_control(
			new WP_Customize_Color_Control(
				$wp_customize,
				'primary_color',
				array(
					'label'       => __( 'Primary Color', 'must-see' ),
					'description' => 'Used for links, buttons, top bar and footer background.',
					'section'     => 'colors',
					'settings'    => 'primary_color',
					'priority'    => 100
				)
			)
		);

		//* Primary Hover Color
		$wp_customize->add_control(
			new WP_Customize_Color_Control(
				$wp_customize,
				'primary_color_hover',
				array(
					'label'       => __( 'Primary Hover Color', 'must-see' ),
					'description' => 'Used for hover states and borders - should be slightly darker (or lighter) than the primary color.',
					'section'     => 'colors',
					'settings'    => 'primary_color_hover',
					'priority'    => 100
				)
			)
		);

		//* Primary Color light
		$wp_customize->add_control(
			new WP_Customize_Color_Control(
				$wp_customize,
				'primary_color_light',
				array(
					'label'       => __( 'Primary Color Light', 'must-see' ),
					'description' => 'Used primarily for top header nav borders and labels - should be lighter than the primary but in the same hue.',
					'section'     => 'colors',
					'settings'    => 'primary_color_light',
					'priority'    => 100
				)
			)
		);
	}

	//* Render CSS
	public function render() {
		?>
		<!-- begin Child Customizer CSS -->
		<style type="text/css">
			<?php

			//* Primary color - link color
			self::generate_css( '
				a,
				.IDX-wrapper-standard a,
				.ae-iconbox i[class*="fa-"],
				.ae-iconbox a i[class*="fa-"],
				.ae-iconbox.type-2:hover i[class*="fa-"],
				.ae-iconbox.type-2:hover a i[class*="fa-"],
				.ae-iconbox.type-3:hover i[class*="fa-"],
				.ae-iconbox.type-3:hover a i[class*="fa-"]
				', 'color', 'primary_color' );

			//* Primary color - backgrounds
			self::generate_css('
				.button,
				button,
				input[type="button"],
				input[type="submit"],
				.top-header,
				.top-bar,
				.top-bar.expanded .title-area,
				.top-bar-section ul li,
				.top-bar-section ul li.active > a,
				.top-bar-section .dropdown li label,
				.top-bar-section .dropdown li a,
				.top-bar-section .dropdown li:not(.has-form) a:not(.button),
				.top-bar-section li:not(.has-form) a:not(.button),
				.footer-widgets,
				.ae-iconbox.type-2 i,
				.ae-iconbox.type-3 i,
				.IDX-wrapper-standard .IDX-btn,
				.IDX-wrapper-standard .IDX-btn-default,
				.IDX-wrapper-standard .IDX-btn-primary,
				.IDX-wrapper-standard #IDX-newSearch,
				.IDX-wrapper-standard #IDX-saveProperty,
				.IDX-wrapper-standard .IDX-removeProperty,
				.IDX-wrapper-standard #IDX-saveSearch,
				.IDX-wrapper-standard #IDX-modifySearch,
				.IDX-wrapper-standard #IDX-submitBtn,
				.IDX-wrapper-standard #IDX-resetBtn,
				.IDX-wrapper-standard #IDX-refineSearchFormToggle,
				.IDX-wrapper-standard #IDX-formReset,
				.IDX-wrapper-standard .IDX-panel-primary>.IDX-panel-heading,
				.IDX-wrapper-standard .IDX-navbar-default,
				.IDX-wrapper-standard .IDX-navigation,
				.IDX-wrapper-standard #IDX-mapHeader-Search,
				.IDX-wrapper-standard .IDX-nav-pills>li.IDX-active>a,
				.IDX-wrapper-standard .IDX-nav-pills>li.IDX-active>a:focus,
				.IDX-wrapper-standard .IDX-nav-pills>li.IDX-active>a:hover
				',
				'background-color', 'primary_color', '', ' !important'
			);

			//* Primary color hover - hover color
			self::generate_css('
				a:hover,
				a:focus
				',
				'color', 'primary_color_hover'
			);

			//* Primary color hover - background color
			self::generate_css('
				.button:hover,
				button:hover,
				input[type="button"]:hover,
				input[type="submit"]:hover,
				.button:focus,
				button:focus,
				input[type="button"]:focus,
				input[type="submit"]:focus,
				.top-bar-section ul li.active > a,
				.top-bar-section .dropdown li:hover,
				.top-bar-section li:not(.has-form):hover > a:not(.button),
				.top-bar-section .dropdown li:not(.has-form):hover > a:not(.button),
				.top-bar-section .dropdown li:not(.has-form):not(.active):hover > a:not(.button),
				.IDX-wrapper-standard .IDX-btn:hover,
				.IDX-wrapper-standard .IDX-btn-default:hover,
				.IDX-wrapper-standard .IDX-btn-primary:hover,
				.IDX-wrapper-standard #IDX-newSearch:hover,
				.IDX-wrapper-standard #IDX-saveProperty:hover,
				.IDX-wrapper-standard .IDX-removeProperty:hover,
				.IDX-wrapper-standard #IDX-saveSearch:hover,
				.IDX-wrapper-standard #IDX-modifySearch:hover,
				.IDX-wrapper-standard #IDX-submitBtn:hover,
				.IDX-wrapper-standard #IDX-resetBtn:hover,
				.IDX-wrapper-standard #IDX-refineSearchFormToggle:hover,
				.IDX-wrapper-standard #IDX-formReset:hover,
				.IDX-wrapper-standard .IDX-btn:focus,
				.IDX-wrapper-standard .IDX-btn-default:focus,
				.IDX-wrapper-standard .IDX-btn-primary:focus,
				.IDX-wrapper-standard #IDX-newSearch:focus,
				.IDX-wrapper-standard #IDX-saveProperty:focus,
				.IDX-wrapper-standard .IDX-removeProperty:focus,
				.IDX-wrapper-standard #IDX-saveSearch:focus,
				.IDX-wrapper-standard #IDX-modifySearch:focus,
				.IDX-wrapper-standard #IDX-submitBtn:focus,
				.IDX-wrapper-standard #IDX-resetBtn:focus,
				.IDX-wrapper-standard #IDX-refineSearchFormToggle:focus,
				.IDX-wrapper-standard #IDX-formReset:focus,
				.IDX-wrapper-standard .IDX-panel-primary>.IDX-panel-heading,
				.IDX-wrapper-standard #IDX-mapHeader-Search,
				.IDX-wrapper-standard .IDX-navbar-nav>.IDX-active>a,
				.IDX-wrapper-standard .IDX-navbar-nav>.IDX-active>a:focus,
				.IDX-wrapper-standard .IDX-navbar-nav>.IDX-active>a:hover,
				.IDX-wrapper-standard .IDX-navbar-nav>li>a:focus,
				.IDX-wrapper-standard .IDX-navbar-nav>li>a:hover,
				.IDX-wrapper-standard .IDX-nav-pills>li.IDX-active>a,
				.IDX-wrapper-standard .IDX-nav-pills>li.IDX-active>a:focus,
				.IDX-wrapper-standard .IDX-nav-pills>li.IDX-active>a:hover,
				.IDX-wrapper-standard .IDX-navbar-default .IDX-navbar-nav > li > a:hover,
				.IDX-wrapper-standard .IDX-navbar-default .IDX-navbar-nav > li > a:focus,
				.IDX-wrapper-standard .IDX-searchNavItem a:hover,
				.IDX-wrapper-standard .IDX-searchNavItem a:focus,
				.IDX-wrapper-standard .IDX-navbar-default .IDX-navbar-nav > .IDX-active > a
				',
				'background-color', 'primary_color_hover', '', ' !important'
			);

			//* Primary color hover - border color
			self::generate_css('
				.button,
				button,
				input[type="button"],
				input[type="submit"],
				.idx-content .IDX-wrapper-standard .IDX-panel-primary,
				.idx-content .IDX-wrapper-standard .IDX-panel-primary>.IDX-panel-heading,
				.idx-content .IDX-wrapper-standard .IDX-navbar-default .IDX-navbar-collapse,
				.idx-content .IDX-wrapper-standard .IDX-navbar-default .IDX-navbar-form,
				.idx-content .IDX-wrapper-standard .IDX-navbar-default
				',
				'border-color', 'primary_color_hover'
			);

			//* Primary color light - color
			self::generate_css('
				.top-bar.expanded .toggle-topbar a,
				.top-bar-section .dropdown label
				',
				'color', 'primary_color_light'
			);

			//* Primary color light - border color
			self::generate_css('
				.top-bar-section .divider,
				.top-bar-section [role="separator"],
				.top-bar-section > ul > .divider,
				.top-bar-section > ul > [role="separator"] 
				',
				'border-color', 'primary_color_light'
			);

			?>
		</style>
		<!-- end Child Customizer CSS -->
		<?php
	}
	
}

add_action( 'init', 'must_see_customizer_init' );
/**
 * Instantiate EQUITY_Customizer
 * 
 * @since 1.0
 */
function must_see_customizer_init() {
	new MUST_SEE_Customizer;
}

add_action( 'wp_enqueue_scripts', 'must_see_parallax_css' );
function must_see_parallax_css() {
	$handle  = defined( 'CHILD_THEME_NAME' ) && CHILD_THEME_NAME ? sanitize_title_with_dashes( CHILD_THEME_NAME ) : 'child-theme';

	$home_top_background = sprintf( get_theme_mod( 'home_top_background', get_stylesheet_directory_uri() . '/images/bkg-home-top.jpg' ));
	$home_bottom_background = sprintf(get_theme_mod( 'home_bottom_background', get_stylesheet_directory_uri() . '/images/bkg-home-bottom.jpg' ));
	if ( equity_get_custom_field( '_equity_singular_header_background' ) ) {
		$singular_header_background = equity_get_custom_field( '_equity_singular_header_background' );
	} else {
		$singular_header_background = get_theme_mod( 'singular_header_background', get_stylesheet_directory_uri() . '/images/bkg-singular-header.jpg' );
	}

	$css  = '';
	$css .= ( ! empty( $home_top_background ) ) ? sprintf( '.home-top { background-image: url(%s); }', $home_top_background ) : '';
	$css .= ( ! empty( $home_bottom_background ) ) ? sprintf( '.home-bottom { background-image: url(%s); }', $home_bottom_background ) : '';
	$css .= ( ! empty( $singular_header_background ) ) ? sprintf( '.entry-header-full { background-image: url(%s); }', $singular_header_background ) : '';

	if( $css ){
		wp_add_inline_style( $handle, $css );
	}
}