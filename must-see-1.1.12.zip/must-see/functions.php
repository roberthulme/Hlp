<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', __( 'Must See Child Theme', 'must-see' ) );
define( 'CHILD_THEME_URL', 'http://www.agentevolution.com/shop/must-see/' );
define( 'CHILD_THEME_VERSION', '1.1.12' );

//* Set Localization (do not remove)
load_child_theme_textdomain( 'must-see', apply_filters( 'child_theme_textdomain', get_stylesheet_directory() . '/languages', 'must-see' ) );

//* Add Theme Support
add_theme_support( 'equity-top-header-bar' );
add_theme_support( 'equity-after-entry-widget-area' );

//* Enqueue parallax script
add_action( 'wp_enqueue_scripts', 'must_see_enqueue_parallax_script' );
function must_see_enqueue_parallax_script() {
	if ( ! wp_is_mobile() ) {
		wp_enqueue_script( 'parallax-script', get_bloginfo( 'stylesheet_directory' ) . '/lib/js/parallax.js', array( 'jquery' ), '1.0.0' );
	}
}

// Add class to body for easy theme identification.
add_filter( 'body_class', 'add_theme_body_class' );
function add_theme_body_class( $classes ) {
	$classes[] = 'home-theme--must-see';
	return $classes;
}

/**
 * Must_see_enqueue_mobile_menu_fix function.
 *
 * Corrects menu behavior on mobile devices.
 */
function must_see_enqueue_mobile_menu_fix() {
	// Fix for mobile nav menu behavior
	wp_enqueue_script( 'mobile-nav-menu-fix', get_stylesheet_directory_uri() . '/lib/js/mobile-nav-menu-fix.js', null, true);
}
add_action( 'wp_enqueue_scripts', 'must_see_enqueue_mobile_menu_fix' );
/**
 * Menu_fix_css function.
 *
 * Corrects menu behavior on mobile devices.
 */
function menu_fix_css() {
	echo '<style type="text/css">@media only screen and (max-width: 640px){.top-bar-section ul .menu-item-has-children .mobile-nav-link-overlay{position:absolute;left:0;top:0;width:55%;height:100%;opacity:0;}}</style>';
}
add_action( 'wp_head', 'menu_fix_css' );

//* Set default footer widgets to 2
if ( get_theme_mod( 'footer_widgets' ) == '' ) {
	set_theme_mod( 'footer_widgets', 2 );
}

//* Create additional color style options
add_theme_support( 'equity-style-selector', array(
	'must-see-blue'   => __( 'Blue', 'must-see' ),
	'must-see-red'    => __( 'Red', 'must-see' ),
	'must-see-tan'    => __( 'Tan', 'must-see' ),
	'must-see-custom' => __( 'Use Customizer', 'must-see' ),
) );

//* Load fonts 
add_filter( 'equity_google_fonts', 'must_see_fonts' );
function must_see_fonts( $equity_google_fonts ) {
	$equity_google_fonts = 'Cardo|Roboto:400,300';
	return $equity_google_fonts;
}

//* Update option to deregister WP Listings widgets CSS (overrides plugin settings)
add_action('after_setup_theme', 'remove_wp_listings_widgets_styles');
function remove_wp_listings_widgets_styles() {
	$new_option = get_option('plugin_wp_listings_settings');
	$new_option['wp_listings_widgets_stylesheet_load'] = 1;
	update_option('plugin_wp_listings_settings', $new_option);
}

//* Add entry header to before content-sidebar wrap for full width background image
add_action( 'equity_before_content_sidebar_wrap', 'equity_child_entry_full_width_header' );
function equity_child_entry_full_width_header() {
	if ( is_singular() && !is_page_template('page_blog.php') && !is_page_template('page_landing.php') && !is_front_page() ) {

		remove_action( 'equity_entry_header', 'equity_entry_header_markup_open', 5 );
		remove_action( 'equity_entry_header', 'equity_entry_header_markup_close', 15 );
		remove_action( 'equity_entry_header', 'equity_do_post_title' );
		remove_action( 'equity_entry_header', 'equity_post_info', 12 );

		add_filter( 'equity_post_title_output', 'equity_child_post_title_output' );
		function equity_child_post_title_output($output) {
			$title = apply_filters( 'equity_post_title_text', get_the_title() );
			if ( 'page' === get_post_type() ) {
				$output  = '<h1 class="entry-title columns small-12">';
			} else {
				$output  = '<h1 class="entry-title columns small-12 large-8">';
			}
			$output .= "{$title}</h1>";
			return $output;
		} 

		while ( have_posts() ) : the_post();

			echo '<div class="entry-header-full">';
				printf( '<header %s>', equity_attr( 'entry-header', $attributes = array( 'class' => 'entry-header row' ) ) );
				if ( 'page' === get_post_type() ) {
					equity_do_post_title();
				} else {
					equity_do_post_title();
					echo '<div class="columns small-12 large-4">';
						equity_post_info();
					echo '</div>';
				}
				echo '</header>';
			echo '</div>';

		endwhile;
	}
}

//* Add body class for singular posts
add_filter( 'body_class', 'add_header_body_class' );
function add_header_body_class( $classes ) {
	if ( is_singular() ) {
		$classes[] = 'has-full-width-header';
	}
	return $classes;
}

//* Filter listing scroller widget prev/next links
add_filter( 'listing_scroller_prev_link', 'child_listing_scroller_prev_link');
function child_listing_scroller_prev_link( $listing_scroller_prev_link_text ) {
	$listing_scroller_prev_link_text = __( '<i class=\"fas fa-angle-left\"></i><span>Prev</span>', 'must-see' );
	return $listing_scroller_prev_link_text;
}
add_filter( 'listing_scroller_next_link', 'child_listing_scroller_next_link');
function child_listing_scroller_next_link( $listing_scroller_next_link_text ) {
	$listing_scroller_next_link_text = __( '<i class=\"fas fa-angle-right\"></i><span>Next</span>', 'must-see' );
	return $listing_scroller_next_link_text;
}
//* Filter IDX listing carousel widget prev/next links
add_filter( 'idx_listing_carousel_prev_link', 'child_idx_listing_carousel_prev_link');
function child_idx_listing_carousel_prev_link( $idx_listing_carousel_prev_link_text ) {
	$idx_listing_carousel_prev_link_text = __( '<i class=\"fas fa-angle-left\"></i><span>Prev</span>', 'must-see' );
	return $idx_listing_carousel_prev_link_text;
}
add_filter( 'idx_listing_carousel_next_link', 'child_idx_listing_carousel_next_link');
function child_idx_listing_carousel_next_link( $idx_listing_carousel_next_link_text ) {
	$idx_listing_carousel_next_link_text = __( '<i class=\"fas fa-angle-right\"></i><span>Next</span>', 'must-see' );
	return $idx_listing_carousel_next_link_text;
}

//* Filter footer output
add_filter( 'equity_footer_output', 'equity_child_footer_output' );
function equity_child_footer_output( $output ) {
	global $footer_left, $footer_right, $footer_disclaimer;
	$output = '
		<div class="columns small-12 large-8 large-centered footer-disclaimer">' . $footer_disclaimer . '</div>
		<div class="columns small-12 large-8 large-centered footer-credits"><span class="footer-left">' . $footer_left . '</span> &middot; <span class="footer-right">' . $footer_right . '</span></div>
	';
	return $output;
}

//* Default widget content
if ( ! is_active_sidebar( 'top-header-left' ) ) {
	add_action('equity_top_header_left', 'top_header_left_default_widget');
}
function top_header_left_default_widget() {
	the_widget( 'WP_Widget_Text', array( 'text' => '[social_icons]') );
}

/**
 * Filter header right menu args to limit depth and add custom walker
 * @param array $args arguments for building the nav menu
 */
add_filter( 'wp_nav_menu_args', 'equity_child_header_menu_args', 10, 1 );
function equity_child_header_menu_args( $args ) {

	if ( 'header-right' == $args['theme_location'] ) {
		$args['depth'] = 2;
		$args['walker'] = new Description_Plus_Icon_Walker;
	}

	return $args;
}

//* Remove default primary nav and add top header nav
add_theme_support( 'equity-menus', array( 'top-header-right' => __( 'Top Header Right', 'must-see' ), 'header-right' => __( 'Header Right', 'must-see' ) ) );

//* Register widget areas
equity_register_widget_area(
	array(
		'id'          => 'home-top',
		'name'        => __( 'Home Top', 'must-see' ),
		'description' => __( 'This is the Top section of the Home page, recommended to use a Home Search widget.', 'must-see' ),
	)
);
equity_register_widget_area(
	array(
		'id'          => 'home-middle',
		'name'        => __( 'Home Middle', 'must-see' ),
		'description' => __( 'This is the Middle section of the Home page, recommended to use a Featured Listings widget.', 'must-see' ),
	)
);
equity_register_widget_area(
	array(
		'id'          => 'home-bottom-1',
		'name'        => __( 'Home Bottom 1', 'must-see' ),
		'description' => __( 'This is the Bottom left section of the Home page. It\'s recommended to use a Custom Menu widget for links. The section heading is defined in Appearance > Customize.', 'must-see' ),
	)
);
equity_register_widget_area(
	array(
		'id'          => 'home-bottom-2',
		'name'        => __( 'Home Bottom 2', 'must-see' ),
		'description' => __( 'This is the Bottom middle section of the Home page. It\'s recommended to use a Custom Menu widget for links. The section heading is defined in Appearance > Customize.', 'must-see' ),
	)
);
equity_register_widget_area(
	array(
		'id'          => 'home-bottom-3',
		'name'        => __( 'Home Bottom 3', 'must-see' ),
		'description' => __( 'This is the Bottom right section of the Home page. It\'s recommended to use a Custom Menu widget for links. The section heading is defined in Appearance > Customize.', 'must-see' ),
	)
);

//* Home page - define home page widget areas for welcome screen display check
add_filter('equity_theme_widget_areas', 'must_see_home_widget_areas');
function must_see_home_widget_areas($active_widget_areas) {
	$active_widget_areas = array( 'home-top', 'home-middle', 'home-bottom-1', 'home-bottom-2', 'home-bottom-3' );
	return $active_widget_areas;
}

//* Home page - markup and default widgets
function equity_child_home() {
	?>
	
	<div class="home-top">
		<div class="row">
			<div class="columns small-12">
			<?php 
				$home_top_title = get_theme_mod( 'home_top_title' );
				if ( $home_top_title )
					echo '<h4 class="widget-title customizer-defined">' . $home_top_title . '</h4>';
				
				if ( ! is_active_sidebar( 'home-top' ) ) {
					the_widget( 'WP_Widget_Text', array( 'title' => 'Find Your Home Now.', 'text' => 'Add the WP Listings Search widget or IDX Search widget here.'), array( 'before_widget' => '<aside class="widget-area">', 'after_widget' => '</aside>', 'before_title' => '<h4 class="widget-title">', 'after_title' => '</h4>' ) );
					
				} else {
					equity_widget_area( 'home-top' );
				}
			?>
			</div><!-- end .columns .small-12 -->
		</div><!-- .end .row -->
	</div><!-- end .home-top -->

	<div class="home-middle">
		<div class="row">
			<div class="columns small-12 large-10 large-centered">
			<?php
				$home_middle_title = get_theme_mod( 'home_middle_title' );
				if ( $home_middle_title )
					echo '<h4 class="widget-title customizer-defined">' . $home_middle_title . '</h4>';

				if ( ! is_active_sidebar( 'home-middle' ) ) {
					the_widget( 'WP_Widget_Text', array( 'title' => 'Latest Listings', 'text' => 'Add the Equity Featured Listings Scroller widget or IDX Listings widget here.'), array( 'before_widget' => '<aside class="widget-area">', 'after_widget' => '</aside>', 'before_title' => '<h4 class="widget-title">', 'after_title' => '</h4>' ) );
				} else {
					equity_widget_area( 'home-middle' );
				}
			?>
			</div><!-- end .columns .small-12 -->
		</div><!-- .end .row -->
	</div><!-- end .home-middle -->

	<div class="home-bottom">
		<div class="row">
			<?php
				$home_bottom_title = get_theme_mod( 'home_bottom_title' );
				if ( $home_bottom_title )
					echo '<h4 class="widget-title customizer-defined columns small-12">' . $home_bottom_title . '</h4>';

				if ( ! is_active_sidebar( 'home-bottom-1' ) ) {
					the_widget( 'WP_Widget_Text', array( 'title' => 'Community One', 'text' => '<ul><li>Setup a Menu of Neighborhoods and</li> <li>add the Custom Menu widget here.</li></ul>'), array( 'before_widget' => '<aside class="widget-area columns small-12 medium-4">', 'after_widget' => '</aside>', 'before_title' => '<h4 class="widget-title">', 'after_title' => '</h4>' ) );
					
				} else {
					equity_widget_area( 'home-bottom-1', array( 'before' => '<aside class="widget-area columns small-12 medium-4">' ) );
				} ?>

				<?php if ( ! is_active_sidebar( 'home-bottom-2' ) ) {
					the_widget( 'WP_Widget_Text', array( 'title' => 'Community Two', 'text' => '<ul><li>Setup a Menu of Neighborhoods and</li> <li>add the Custom Menu widget here.</li></ul>'), array( 'before_widget' => '<aside class="widget-area columns small-12 medium-4">', 'after_widget' => '</aside>', 'before_title' => '<h4 class="widget-title">', 'after_title' => '</h4>') );
					
				} else {
					equity_widget_area( 'home-bottom-2', array( 'before' => '<aside class="widget-area columns small-12 medium-4">' ) );
				} ?>

				<?php if ( ! is_active_sidebar( 'home-bottom-3' ) ) {
					the_widget( 'WP_Widget_Text', array( 'title' => 'Community Three', 'text' => '<ul><li>Setup a Menu of Neighborhoods and</li> <li>add the Custom Menu widget here.</li></ul>'), array( 'before_widget' => '<aside class="widget-area columns small-12 medium-4">', 'after_widget' => '</aside>', 'before_title' => '<h4 class="widget-title">', 'after_title' => '</h4>') );
					
				} else {
					equity_widget_area( 'home-bottom-3', array( 'before' => '<aside class="widget-area columns small-12 medium-4">' ) );
				}
			?>
		</div><!-- .end .row -->
	</div><!-- end .home-bottom -->

<?php
}

//* Includes

# Theme Customizatons
require_once get_stylesheet_directory() . '/lib/customizer.php';

# Recommended Plugins
require_once get_stylesheet_directory() . '/lib/plugins.php';

# Custom metaboxes
require_once get_stylesheet_directory() . '/lib/metaboxes.php';